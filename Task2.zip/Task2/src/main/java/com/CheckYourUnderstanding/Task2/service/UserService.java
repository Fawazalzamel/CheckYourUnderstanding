package com.CheckYourUnderstanding.Task2.service;

import com.CheckYourUnderstanding.Task2.bo.CreateUserRequest;

public interface UserService {

    void saveUser(CreateUserRequest createUserRequest);
}
