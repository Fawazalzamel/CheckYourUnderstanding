package com.CheckYourUnderstanding.Task2.userController;

import com.CheckYourUnderstanding.Task2.service.UserService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.CheckYourUnderstanding.Task2.bo.CreateUserRequest;


@RestController
public class UserController {
    private final UserService userService;

    public UserController(UserService userService){
        this.userService = userService;
    }

    @PostMapping("/create-user")
    public ResponseEntity<String> createUser(@RequestBody CreateUserRequest createUserRequest){
        userService.saveUser(createUserRequest);
    return ResponseEntity.ok("User Created Successfully");
}
}
